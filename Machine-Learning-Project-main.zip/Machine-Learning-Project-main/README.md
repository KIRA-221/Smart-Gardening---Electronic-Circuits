# Machine-Learning-Project
Fake news Detection using python.
In our project, we collected data from an authentic
source and pre-processed those bt TF/IDF. Then we test train
and split those data as our preference. We used some models
to train data like Decision Tree, Random Forest, Gradient
Boosting, Passive Aggressive, etc. The algorithms we used
were passive-aggressive classifier, multinominal classifier, and
logistic regression. Then we just test on the Holdout set and
after getting the result we just picked the model which gave
us the best result.
